# Web Scraper

A Python-based web scraper for extracting financial data from multiple sources and saving it for analysis.